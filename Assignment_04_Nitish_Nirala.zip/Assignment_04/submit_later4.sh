#!/bin/bash

#j=1
#for i in {a..z}
#do
#touch "data/$j$i.jpg"
#((j++))
#done

for i in `ls data/`;
do
	source="data/$i"
	first_name=`echo $i | cut -d"." -f1`
	new_name="$first_name.txt"
	destination="data/$new_name"
	mv $source $destination
done

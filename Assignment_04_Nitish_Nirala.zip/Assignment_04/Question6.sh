#!/bin/bash

a=$1
b=$2
c=$3

if [[ $a -gt $b ]]
then
	if [[ $a -gt $c ]]
	then 
		echo "The greatest number among $a, $b and $c is " $a
	fi
	elif [[ $b -gt $c ]]
	then
		echo "The greatest number among $a, $b and $c is " $b
	else
		echo "The greatest number among $a, $b and $c is " $c
fi

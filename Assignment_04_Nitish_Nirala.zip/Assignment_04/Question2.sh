#!/bin/bash

read -p "enter initial range: " r1
read -p "enter end range: " r2
echo "The Odd numbers are"
for ((i=r1;i<=r2;i++))
do
if [[ $i%2 -ne 0 ]]
then
	echo $i
fi
done

#!/bin/bash

mkdir data

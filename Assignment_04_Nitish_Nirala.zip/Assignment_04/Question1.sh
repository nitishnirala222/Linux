#!/bin/bash

read -p "enter inital range: " r1
read -p "enter end range: " r2
echo "The Even numbers are"
for (( i=r1;i<=r2;i++ ))
do
if [[ $i%2 -eq 0 ]]
then
	echo $i
fi
done

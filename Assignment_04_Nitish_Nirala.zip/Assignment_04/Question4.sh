#!/bin/bash

a=$1
b=$2

c=$((a-b))

echo "The subtration of $a and $b is $c"

#!/bin/bash

a=$1
b=$2

m=$((a*b))

echo "multiplication of $a and $b is $m"

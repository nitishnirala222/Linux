#!/bin/bash

read -p "enter initial range: " r1
read -p "enter end range: " r2

for ((i=r1;i<=r2;i++))
do
	touch "Data1/$i.txt"
done

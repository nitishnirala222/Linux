#!/bin/bash

read -p "enter a number to check even or odd: " n

if [[ n%2 -eq 0 ]]
then 
echo "The entered number is even"
else
echo "The entered number is odd";
fi

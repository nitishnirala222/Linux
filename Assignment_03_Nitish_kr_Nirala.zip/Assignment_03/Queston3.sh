#!/bin/bash

read -p "enter 1st number: " n1
read -p "enter 2nd number: " n2

mult=$((n1*n2))

echo "The Multiplication of these two number is: "$mult

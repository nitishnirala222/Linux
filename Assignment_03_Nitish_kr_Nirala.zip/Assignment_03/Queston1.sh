#!/bin/bash

read -p  "enter 1st number: " n1
read -p  "enter 2nd number: " n2

add=$((n1+$n2))

echo "The Addition of these two number is: " $add

#!/bin/bash

a=100
b=750
c=200

if [[ $a -gt $b ]]
then
	if [[ $a -gt $c ]]
	then 
		echo "The greatest number is: " $a
		fi
		elif [[ $b -gt $c ]]
		then
			echo "The greatest number is: " $b 
			
				else
					echo "The greatest number is: " $c
			
			fi



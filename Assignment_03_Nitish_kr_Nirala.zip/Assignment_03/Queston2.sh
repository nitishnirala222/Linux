#!/bin/bash

read -p "enter 1st number: " a
read -p "enter 2nd number: " b

sub=$((a-b))

echo "The subtraction of these two number is: "$sub

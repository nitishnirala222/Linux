#!/bin/bash

read -p "enter the file name or absolute path: " file

if [[ -f $file ]]
then

	if [[ -w $file ]]
	then
	    if [[ -r $file ]]
		then
		if [[ -x $file ]]
		  then
	        	echo "This $file has already readable, writable and executable permission"
			else
			chmod u+w,u+r,u+x $file
			ls -l $file
			fi
			fi
			fi
fi

#!/bin/bash

echo "1. for addition"
echo "2. for subtraction"
echo "3. for multiplication"
echo "4. for division"
read -p "enter 1st number: " a
read -p "enter 2nd number: " b
read -p "enter your choice: " ch
if [[ $ch -eq 1 ]]
then 
echo "The addition of $a and $b is $(($a+$b))"
elif [[ $ch -eq 2 ]]
then
echo "The subtraction of $a and $b is $(($a-$b))"
elif [[ $ch -eq 3 ]]
then
echo "The multiplication of $a and $b is $(($a*$b))"
elif [[ $ch -eq 4 ]]
then
echo "The division of $a and $b is $(($a/$b))"
else
echo "please choose correct option"
fi

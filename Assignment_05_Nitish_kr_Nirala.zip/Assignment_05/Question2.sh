#!/bin/bash
read -p "enter a number to check prime number: " n
count=0;
for ((i=2;i<=$((n/2));i++ )); 
do
if [[ n%i -eq 0 ]]
then
((count++))
fi
done
if [[ count -eq 0 ]]
then
echo "The number $n is a prime number"
else 
echo "The number $n is not a prime number"
fi

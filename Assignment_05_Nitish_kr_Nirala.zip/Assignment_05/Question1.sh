#!/bin/bash

sum(){
a=$1
b=$2
echo "The sum of $a and $b is " $((a+b))
}
sub()
{
a=$1
b=$2
echo "The subtraction of $a and $b is " $((a-b))
}
mult()
{
a=$1
b=$2
echo "The multiplication of $a and $b is " $((a*b))
}
Div()
{
a=$1
b=$2
echo "The Division of $a and $b is " $((a/b))
}

while true;
do
echo "1. for Addition"
echo "2. for Subtraction"
echo "3. for Multiplication"
echo "4. for Division"
echo "5. for exit"

read -p "enter 1st number: " a
read -p "enter 2nd number: " b

read -p "enter your choice: " ch
case $ch in
("1") sum $a $b
;;
("2") sub $a $b
;;
("3") mult $a $b
;;
("4") Div $a $b
;;
("5") exit
;;
(*) echo "please choose valid option"
;;
esac
echo "______________________________________________________"
done

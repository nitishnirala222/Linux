#!/bin/bash

arr=()

arr+=("ls -l")


echo ${#arr[@]};

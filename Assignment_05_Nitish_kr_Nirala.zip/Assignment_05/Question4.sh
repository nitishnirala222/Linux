#!/bin/bash
name=()
while true;
do
echo "1. for Add employee's name"
echo "2. for Delete employee's name"
echo "3. for display employee's name"
echo "4. for search employee's name"
echo "5. for exit"
read -p "enter your choice: " option

case $option in
"1") read -p "enter employee's name: " str
name+=($str)
;;
"2") read -p  "enter employee's name to be delete: " ename
l=${#name[@]}
for ((i=0;i<$l;i++))
do
count=0
if [[ ${name[i]} == $ename ]]
then
unset name[i]
echo "deleted successfully"
else
((count++))
fi
done 
if [[ count -gt 0 ]]
then
echo "employee doesn't exist"
fi
;; 
"3") echo "employee's names are: "
for i in ${name[@]}
do
	echo $i
done
;;
"4")
read -p "search employee's name: " en
count=0;
for i in ${name[@]};
do
if [[ $i == $en ]]
then
((count++))
fi
done
if [[ count -eq 1 ]]
then
echo "employee exists"
else 
echo "employee doesn't exist"
fi 
;;
"5") exit
;;
*) echo "please choose correct option"
;;
esac 
echo "________________________________________________________"
done

